import {conf} from "../conf/conf.js";
import { Client, Account, Databases, ID, Storage, Query } from "appwrite";
export class AppwriteShastarService {
  client = new Client();
  database;
  bucket;
  constructor() {
    // 🪶: auto runs, first whena class is created
    this.client
      .setEndpoint(conf.appwriteEndpoint)
      .setProject(conf.appwriteProjectId);
    this.database = new Databases(this.client);
    this.bucket = new Storage(this.client);
  }

  async createShastar(data) {
    try {
      return await this.database.createDocument(
        conf.appwriteDatabaseId,
        conf.appwriteCollectionId,
        ID.unique(),
        data
      );
    } catch (error) {
      // alert(error);
      console.error('Error creating Shastar:', error);
      throw error;
    } finally{
            console.log("Done :: Outside createShastar()");
      
    }
  }
  
  async updateShastar(documentId, data) {
    try {
      return await this.database.updateDocument(
        conf.appwriteDatabaseId,
        conf.appwriteCollectionId,
        documentId,
        data
      );
    } catch (error) {
      // alert(error);
      console.error('Error updating Shastar:', error);
      throw error;
    }
  }

 
  //----   DISPLAYS A SINGLE Shastar BASED UPON GIVEN PARAMETERS BY IDENTIFYING ITS ID AS A SLUG ----*/
async readShastar(slug) {
    try {
      return await this.database.getDocument(
        conf.appwriteDatabaseId,
        conf.appwriteCollectionId,
        slug
      );
    } catch (errorFound) {
      // alert(errorFound);
      console.log(
        "Appwrite-ShastarService error :: at readShastar() :: ",
        errorFound
      );
    }
  }
  //----  DISPLAYS EVERY SINGLE Shastar REGARDLESS OF WHETHER STAUS IS SET TO TEMP/PERMANENT ----*/
  async getEveryShastar(queries) {
    try {
      const getEveryShastarResult = await this.database.listDocuments(
        conf.appwriteDatabaseId,
        conf.appwriteCollectionId,
        queries // get all Shastars of currently logged in user
      );
      // console.log("getEveryShastarResult() config.js: ",getEveryShastarResult);
      
      return getEveryShastarResult;
    } catch (errorFound) {
      // alert(errorFound);
      console.log(
        "Appwrite-ShastarService error config.js :: at getEveryShastar() :: ",
        errorFound
      );
    }
  }
  //----  DISPLAYS ALL SAVED/PERMANENT ShastarS ----*/
  async getSavedShastars() {
    try {
      return await this.database.listDocuments(
        conf.appwriteDatabaseId,
        conf.appwriteCollectionId,
        [Query.equal("status_idx", ["permanent"])] // queries (optional)
      );
    } catch (errorFound) {
      // alert(errorFound);
      console.log(
        "Appwrite-ShastarService error config.js :: at getSavedShastars() :: ",
        errorFound
      );
    }
  }
 
  //----  UPDATES A Shastar BASED UPON GIVEN PARAMETERS BY IDENTIFYING ITS ID AS A SLUG ----*/
  // async updateShastar(slug, { title, content, status }) {
  //   try {
  //     return await this.database.updateDocument(
  //       conf.appwriteDatabaseId,
  //       conf.appwriteCollectionId,
  //       // slug,
  //       ID.unique(),
  //       { title, content, status }
  //     );
  //   } catch (errorFound) {
  // alert(errorFound);
  //     console.log(
  //       "Appwrite-ShastarService error :: at updateShastar() :: ",
  //       errorFound
  //     );
  //   }
  // }
  //----  PERFORMS DELETION OF A Shastar BASED UPON GIVEN PARAMETERS BY IDENTIFYING ITS ID AS A SLUG ----*/
  async deleteShastar(ShastarId) {
    // console.clear()
    console.log("operation executed for Shastar: ",ShastarId);
    try {
       await this.database.deleteDocument(
        conf.appwriteDatabaseId,
        conf.appwriteCollectionId,
        ShastarId       
      );
    } catch (errorFound) {
      // alert(errorFound);
      console.log("Appwrite-ShastarService error :: at deleteShastar() :: ",errorFound);
      return false;
    }
    return true;
  }
  async uploadShastarImage(file) {
    // console.clear()
    console.log("operation executed for Shastar: ");
    try {
       return await this.bucket.createFile(
        conf.appwriteBucketId,
         ID.unique(),
         file
    // document.getElementById('imageOfShastar').files[0]     
      );
      console.log("file received",document.getElementById('imageOfShastar').files[0]);
      
    } catch (errorFound) {
      // alert(errorFound);
      console.log("Appwrite-ShastarService error :: at uploadShastarImage() :: ",errorFound);
      return false;
    }
    // return true;
  }
  async viewShastarImage(file) {
    // console.clear()
    console.log("operation executed for file: ",file);
    try {
       return await this.bucket.getFileView(
        conf.appwriteBucketId,
         file
    // document.getElementById('imageOfShastar').files[0]     
      );
      console.log("file received",document.getElementById('imageOfShastar').files[0]);
      
    } catch (errorFound) {
      // alert(errorFound);
      console.log("Appwrite-ShastarService error :: at uploadShastarImage() :: ",errorFound);
      return false;
    }
    // return true;
  }
}
const appwriteShastarService = new AppwriteShastarService(); // exported ready-made object of  'class AppwriteShastarService'
export default appwriteShastarService;
