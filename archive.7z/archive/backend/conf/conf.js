export const conf = {
    appwriteProjectId: String(import.meta.env.VITE_APPWRITE_PROJECT_ID),
    appwriteEndpoint: String(import.meta.env.VITE_APPWRITE_ENDPOINT),
    appwriteApiFullAccess: String(import.meta.env.VITE_APPWRITE_API_FULL_ACCESS),

    appwriteDatabaseId: String('6864f4fb00182a5e9c32'),
    appwriteCollectionId: String('6864f5030016e18369ae'),
    appwriteBucketId: String('6864f5f70025e7dc167d'),
};

export const APP_NAME="Kosh"
export const APP_DESCRIPTION=""