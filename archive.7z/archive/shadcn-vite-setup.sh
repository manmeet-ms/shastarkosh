bun create vite@latest
bun add tailwindcss @tailwindcss/vite
touch tsconfig.json
touch tsconfig.app.json
