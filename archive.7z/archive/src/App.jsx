// TODO searcheable, category filters based on country
// TODO country combobox in form, to unifirm for filter
// TODO progress indicator
// TODO loading states when upokadionjg Images, to prevent dummy imge fom being pushed
// TODO update and delete permissions to authenticated users
// TODO like, share and edit  button (approval edit based type)
// TODO fields: alternate names, timeItExisted, adv/disadv of weapon, category[melee/shastar,gupt, chalayejaanewala/astar]
// TODO short desription made-up: __name__ during the period of __time(enter the duration like 18thcentryre,2000-2100)__ originating from __country__
// TODO sort the filter with new/old/...
import Masonry from '@mui/lab/Masonry';
import { ThemeProvider } from '@/components/theme-provider';
import { Header } from './components/Headers/Header';
import { Footer } from './components/Footers/Footer';
import NewShastarSubmission from './components/Forms/NewShastarSubmission';
import { Button } from '@/components/ui/button';
import appwriteShastarService from '../backend/appwrite/shastarsCRUD';
import { useCallback, useEffect, useState } from 'react';
import { ArrowRightIcon, HeartIcon, PencilLineIcon, Share2Icon, ShareIcon } from 'lucide-react';
import { Link } from 'react-router';

function App() {
    const [shastarsList, setShastarsList] = useState([]);
    const [loading, setLoading] = useState(true);
    const fetchShastars = useCallback(async () => {
        // prevent unnecessary API calls

        try {
            const fetchedShastars = await appwriteShastarService.getEveryShastar();
            // console.log("loggin this", fetchedShastars.documents[0].$createdAt);

            if (fetchedShastars && fetchedShastars.documents) {
                setShastarsList(fetchedShastars.documents.reverse()); // to sorrt the shastarsList in (latest created) order
                console.log('fetchShastars>>try>> fetchedShastars>> shastarsList', shastarsList);
            }
        } catch (error) {
            console.error('Error fetching shastarsList:', error);
        }
    }, []); // Only recreate when userId changes

    const generateTestData = async () => {
        const bulkShastars = [
            {
                name: 'bichwa',
                description: 'bichwa bichwa bichwa',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'baghnakha',
                description: 'baghnakha baghnakha baghnakha',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'limcha',
                description: 'limcha limcha limcha',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'barcha',
                description: 'barcha barcha barcha',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'neja',
                description: 'neja neja neja',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'katar/jamdadh',
                description: '"katarjamdadh jamdadh jamdadh',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'teer',
                description: 'teer teer teer',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'dhanush/bow/fact:225kg;9tnkDaDhanush',
                description: '"dhanush/bow/fact:225kg9tnkDaDhanush 9tnkDaDhanush 9tnkDaDhanush',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'kati',
                description: 'kati kati kati',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'sarohi',
                description: 'sarohi sarohi sarohi',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
            {
                name: 'goliy',
                description: 'goliy goliy goliy',
                proof: '',
                country_of_origin: '',
                shastar_img_id: null,
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
            },
        ];
        const testNotes = [
            {
                name: 'shamrock',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRY3xG2swm0OcVj3YGPS1XHS_idqNjGqddBQA&s`,
                description: 'Finish reading 20 pages of the new book, spend 30 minutes exercising, and organize your workspace for better productivity.',
            },
            {
                name: 'VINCENT',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3R2BYnt3XOJcEevqH-WvwmOHf-trpD4qDpfjpVnZqsSoM_ddQrrrM_NO38W0EhvQnil4&usqp=CAU`,
                description: 'Brainstorm concepts for the new app. Focus on unique features, usability, and how it can address customer pain points.',
            },
            {
                name: 'Raiden ',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://m.media-amazon.com/images/S/aplus-media-library-service-media/ed362988-5231-4f82-b83a-695fc2ad857c.__CR414,0,2134,1320_PT0_SX970_V1___.jpg`,
                description: `<strong>Reminder:</strong> Set a timer for 25 minutes and focus solely on the task at hand. <em>No distractions allowed!</em>`,
            },
            {
                name: 'remington',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdRr8qdeq0yXHyzF_Got3jS8yL_ObqGM-5LUCMgfpFefIc0xYj6WuwpejbeR0SIj8UE8Q&usqp=CAU`,
                description: `Check <a href="https://example.com/resources" target="_blank">this link</a> for study resources. Highlight key points from Chapters 3-5.`,
            },
            {
                name: 'Bichwa',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://m.media-amazon.com/images/S/aplus-media-library-service-media/ed362988-5231-4f82-b83a-695fc2ad857c.__CR414,0,2134,1320_PT0_SX970_V1___.jpg`,
                description: `<ul>
    <li>Review all action items from last week.</li>
    <li>Draft key discussion points for the new module.</li>
    <li>Confirm timelines for deliverables.</li>
    </ul>`,
            },
            {
                name: 'Vihangam',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyUBuq0t4NMVCxhw5TwGq68dYrPRdYmZCWz3ABGXIcjTCisq4bKqvlYn9ZkuMlIoZsEeU&usqp=CAU`,
                description: `Today, prioritize your <b>mental health</b>. Take a 15-minute mindfulness break and try a new hobby.`,
            },
            {
                name: 'harriet',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://ih1.redbubble.net/image.1708018982.2680/st,small,507x507-pad,600x600,f8f8f8.jpg`,
                description: `<pre><code>function greetUser(name) {
    return \`Hello, \${name}!\`;
  }</code></pre> Test this snippet for personalized messages.`,
            },
            {
                name: 'Thunderbird',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://m.media-amazon.com/images/S/aplus-media-library-service-media/ed362988-5231-4f82-b83a-695fc2ad857c.__CR414,0,2134,1320_PT0_SX970_V1___.jpg`,
                description: `Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.Discuss project updates and finalize the roadmap.END END END`,
            },
            {
                name: 'Pata',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://m.media-amazon.com/images/S/aplus-media-library-service-media/ed362988-5231-4f82-b83a-695fc2ad857c.__CR414,0,2134,1320_PT0_SX970_V1___.jpg`,
                description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis modi asperiores quod deserunt! Voluptas, expedita.<br><li>Buy groceries</li><li>Pick up laundry</li><li>Call the plumber</li><li>Buy groceries</li><li>Pick up laundry</li><li>Call the plumber</li> ',
            },
            {
                name: 'Serrated Blade',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://m.media-amazon.com/images/S/aplus-media-library-service-media/ed362988-5231-4f82-b83a-695fc2ad857c.__CR414,0,2134,1320_PT0_SX970_V1___.jpg`,
                description: "Complete the math assignment, revise chemistry shastarsList, and prep for tomorrow's quiz. Don't forget to go over the calculus problems you missed last week. Focus on Chapter 6 and the practice test.",
            },
            {
                name: 'Ankusha',
                proof: 'https://trustthawarrior.co',
                country_of_origin: 'India',
                shastar_img_id: '000000000',
                shastar_img_url: `https://m.media-amazon.com/images/S/aplus-media-library-service-media/ed362988-5231-4f82-b83a-695fc2ad857c.__CR414,0,2134,1320_PT0_SX970_V1___.jpg`,
                description: `Stay focused today. Small steps lead to big success eventually!`,
            },
        ];

        for (const note of testNotes) {
            await appwriteShastarService.createShastar({
                ...note,
            });
        }

        // Refresh shastarsList after generating test data
        fetchShastars();
    };

    // Fetch shastarsList when user data is available
    useEffect(() => {
        fetchShastars();
    }, [fetchShastars]); // Depend on memoized fetchShastars

    return (
        <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
            <main className="px-4 flex flex-col space-y-4">
                <Header />
                <section className="">
                    <section className="flex justify-between pb-12">
                        <h1 className="text-2xl font-medium">
                            Lorem ipsum dolor sit
                            <span className="text-sm font-normal text-muted-foreground block ">Total documents in infobase: {shastarsList.length}</span>
                        </h1>

                        <div className="flex gap-2">
                            <Button variant="outline" onClick={fetchShastars}>
                                Refresh
                            </Button>
                            <Button onClick={generateTestData} variant="ghost">
                                Generate test data
                            </Button>
                        </div>
                    </section>
                    <section className="text-muted-foreground  container w-full ">
                        <div className="container ">
                            <div className="flex flex-wrap -m-4">
                                <Masonry columns={{ xs: 1, sm: 2, md: 2, lg: 3 }} spacing={1}>
                                    {shastarsList.map((item, idx) => {
                                        return (
                                            <div key={idx} className="  overflow-hidden p-4 bg-accent-foreground/5 hover:bg-accent-foreground/10 transition-all duration-200 ease-in-out  border border-accent-foreground/10 rounded-xl ">
                                                <div className="h-full flex sm:flex-row flex-col items-start sm:justify-start justify-center  ">
                                                    <img alt="shastar" className=" flex-shrink-0 rounded-lg w-36 h-36 object-cover object-center sm:mb-0 mb-4" src={item.shastar_img_url || 'https://dummyimage.com/200x200'} />
                                                    <div className="flex-grow sm:pl-4">
                                                        <div className="flex justify-between items-center">
                                                            <h2 className=" font-medium text-lg text-accent-foreground capitalize truncate w-content ">{item.name}</h2>

                                                            {/* <span className="inline-flex">
                                                                <PencilLineIcon className=" p-2   hover:text-gray-300 rounded-full transition-colors  duration-500 ease-in-out  " size={32} strokeWidth={2.25} />
                                                                <Share2Icon className=" p-2   hover:text-gray-300 rounded-full transition-colors  duration-500 ease-in-out  " size={32} strokeWidth={2.25} />
                                                            </span> */}
                                                        </div>
                                                        <p className=" line-clamp-2 ">{item.description}.</p> {/* TODO more detailed list card */}
                                                        {/* Country of origin: <h3 className="bg-accent text-xs inline rounded-full px-2 py-1   ">{item.country_of_origin}</h3> <br />
                    Lethality scale:5  */}
                                                        <h3 className="  text-xs inline   ">Origin: {item.country_of_origin}</h3> <br />
                                                        <div className="flex items-center">
                                                            {' '}
                                                            <Link to={`/s/${shastarsList[idx].$id}`} className="   underline text-sm font-medium ">
                                                                <Button variant="outline" className="my-2 mr-2">
                                                                    {' '}
                                                                    View Details 
                                                                    {/* <ArrowRightIcon className="inline " size={16} strokeWidth={2.5} /> */}
                                                                </Button>
                                                            </Link>
                                                            <HeartIcon className=" p-2 text-accent-foreground/60 hover:bg-rose-400/40 hover:text-rose-300 rounded-full transition-colors  duration-500 ease-in-out  " size={32} strokeWidth={2.25} />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </Masonry>
                            </div>
                        </div>
                    </section>
                    {/* notification center */}
                    <section></section>
                </section>

                <NewShastarSubmission />
                <Footer />
            </main>
        </ThemeProvider>
    );
}

export default App;
