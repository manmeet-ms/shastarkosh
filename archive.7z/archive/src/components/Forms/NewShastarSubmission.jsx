import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

import { Check, ChevronsUpDown, PencilIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import appwriteShastarService from '../../../backend/appwrite/shastarsCRUD';
const frameworks = [
    {
        value: 'next.js',
        label: 'Next.js',
    },
    {
        value: 'sveltekit',
        label: 'SvelteKit',
    },
    {
        value: 'nuxt.js',
        label: 'Nuxt.js',
    },
    {
        value: 'remix',
        label: 'Remix',
    },
    {
        value: 'astro',
        label: 'Astro',
    },
];
let i = 0;
const NewShastarSubmission = () => {
    // combobox
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('');
    //   formdata
    const [formData, setformData] = useState();
    const [previewLink, setpreviewLink] = useState('https://placehold.co/1084x1284');
    const [fileID, setFileID] = useState('00000000');
    const [fileURL, setFileURL] = useState('https://placehold.co/1084x1284');
    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
    } = useForm();
    const onSubmit = async (data) => {
        
        const finalData = {
            ...data,
            shastar_img_id: fileID,
            shastar_img_url: previewLink,
        };

        console.log('Final data:', finalData);
        await appwriteShastarService.createShastar({ name: finalData.r_name, description: finalData.r_description, proof: finalData.r_proof, country_of_origin: finalData.r_countryOfOrigin, shastar_img_id: fileID, shastar_img_url:previewLink });
        
    };
    // console.log(i++, watch('countryOfOrigin'));
    // console.log(watch('file.0'));

    // TODO: better structure

    const createlocalFile = async () => {
        console.log('::: upload file :: createlocalFile fn called ::: ');

        const createResult = await appwriteShastarService.uploadShastarImage();
        console.log('file uploaded :: createResult :: ', createResult);
        console.log('file ID received :: ', createResult.$id);
        setFileID(createResult.$id);
    };
    const createlocal = async () => {
        // createlocalFile();

        const createResult = await appwriteShastarService.createShastar({ name: 'defualt_shastart', description: 'lorem defualt_shastart', country_of_origin: 'ind', proof: 'trust', shastar_img: fileID });
        console.log(createResult);
    };

    return (
        <section className=''>
            <Dialog>
              <DialogTrigger className="fixed z-[99] bottom-6 right-8 backdrop-blur-2xl px-5 py-3 rounded-lg  bg-primary font-medium text-primary-foreground" >
              <PencilIcon className="inline-flex items-center mr-2 mb-0.25" size={16} strokeWidth={2.5} />
              Add Shastar</DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Are you absolutely sure?</DialogTitle>
                  <DialogDescription>
                    <div className="flex flex-col gap-6 items-center justify-center">
            <Card className="overflow-hidden p-0">
                <CardContent className="grid p-0  ">
                    <form onSubmit={handleSubmit(onSubmit)} className="flex p-6 md:p-8">
                        <div className="">
                            <div className="flex flex-col gap-6">
                                <div className="  items-center text-center">
                                    <h1 className="text-2xl font-bold">Add new shastar</h1>
                                    <p className="text-muted-foreground text-balance">Provide accurate info. Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, iste?</p>
                                </div>
                                <div className="grid gap-3">
                                    <Label htmlFor="name">Name</Label>
                                    <Input
                                        defaultValue="ShastarKosh Shastar"
                                        {...register('r_name')}
                                        id="name"
                                        type="name"
                                        placeholder="Enter"
                                        required
                                    />
                                </div>
                                <div className="grid gap-3">
                                     
                                        <Label htmlFor="description">Description</Label>
                                        <Textarea
                                            {...register('r_description')}
                                            id="description"
                                            defaultValue="Lorem ipsum dolor sit amet consectetur adipisicing elit."
                                            placeholder="Enter"
                                        />
                                </div>
                                <div className="grid gap-3">
                                    {/* // TODO: pending link validation valid https */}
                                    <Label htmlFor="proof">Proof link</Label>
                                    <Input
                                        defaultValue="https://tailblocks.cc/"
                                        {...register('r_proof')}
                                        id="proof"
                                        type="text"
                                        placeholder="Enter"
                                        required
                                    />
                                </div>
                                <span className="opacity-30"> selectable categoies</span>
                                <div className="grid gap-3">
                                    <Label htmlFor="countryOfOrigin">Country of origin</Label>
                                    {/* // TODO combobox ofr later  */}
                                    <Input
                                        defaultValue="Afganistan"
                                        {...register('r_countryOfOrigin')}
                                        id="origin"
                                        type="text"
                                        placeholder="Country of origin"
                                    />
                                </div>
                                <Button type="submit">Submit</Button>
                            </div>
                        </div>
                        <div className="bg-muted container relative">
                            <div className="grid gap-3">
                                <Label htmlFor="file">Image of the shastar</Label>
                                <Input
                                    id="imageOfShastar"
                                    type="file"
                                    accept="image/*"
                                    {...register('r_shastarImgObject')}
                                    onChange={async (e) => {
                                        const file = e.target.files && e.target.files[0];
                                        if (!file) return;

                                        try {
                                            const createResult = await appwriteShastarService.uploadShastarImage(file);
                                            console.log('Uploaded file result:', createResult);
                                            setFileID(createResult.$id);
                                            const gettingPreviewLink=await appwriteShastarService.viewShastarImage(createResult.$id) // Save the file ID
                                            setpreviewLink(gettingPreviewLink)
                                            console.log(gettingPreviewLink);
                                            
                                        } catch (err) {
                                            console.error('File upload failed:', err);
                                        }
                                    }}
                                />
                                <img className="w-96 p-6 rounded-xl" src={previewLink} />
                                {/* <Input
                                 {...register('r_shastarFileID')} id="fileIdOfShastar" value={fileID} type="text" placeholder="nothing" /> */}
                            </div>
                        </div>{' '}
                    </form>
                </CardContent>
            </Card>
            <div className="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">
                <Checkbox /> By clicking continue, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.{/* TODO: BAAD ME BANAYENGE TOS AND POLICIES */}
            </div>
        </div>
                  </DialogDescription>
                </DialogHeader>
              </DialogContent>
            </Dialog>
        </section>
    );
};

export default NewShastarSubmission;
