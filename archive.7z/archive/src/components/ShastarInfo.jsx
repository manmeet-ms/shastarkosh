import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
  BreadcrumbEllipsis,
} from "@/components/ui/breadcrumb"
import { Button } from '@/components/ui/button';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import appwriteShastarService from '../../backend/appwrite/shastarsCRUD';
import { Footer } from './Footers/Footer';
import { Header } from './Headers/Header';
import { HeartIcon, HomeIcon, PencilLineIcon, Share2Icon } from 'lucide-react';

const ShastarInfo = () => {
    let params = useParams();
    const [first, setfirst] = useState({});
    const displaySingleShastar = async () => {
        try {
            const result = await appwriteShastarService.readShastar(params.shastarDocId);
            console.log(result, document.baseURI);

            setfirst(result);
        } catch (error) {
            console.log(error);
        }
    };
    useEffect(() => {
        displaySingleShastar();
        console.log('under useEffect(()', document.baseURI);
    }, []);

    return (
        <>
          <main className='px-5'>  <Header />

         {!first &&    <Button onClick={displaySingleShastar}>Refresh Data</Button>
           }
<Breadcrumb>
  <BreadcrumbList>
    <BreadcrumbItem>
      <BreadcrumbLink href="/"><HomeIcon size={16}/></BreadcrumbLink>
    </BreadcrumbItem>
    <BreadcrumbSeparator />
    <BreadcrumbItem>
      <BreadcrumbLink href="/">Shastars</BreadcrumbLink>
    </BreadcrumbItem>
    <BreadcrumbSeparator />
    <BreadcrumbItem>
      <BreadcrumbLink className="capitalize">{first.country_of_origin}</BreadcrumbLink>
    </BreadcrumbItem>
    <BreadcrumbSeparator />
    <BreadcrumbItem>
      <BreadcrumbPage>{first.name}</BreadcrumbPage>
    </BreadcrumbItem>
  </BreadcrumbList>
</Breadcrumb>
            {first &&  <section className="text-muted-foreground   overflow-hidden">
                <div className="container px-5 py-24 mx-auto">
                    <div className="lg:w-4/5 mx-auto flex flex-wrap">
                        <img alt="ecommerce" class="lg:w-1/2 w-full lg:h-auto h-64 object-cover object-center rounded" src={first.shastar_img_url} />
                        <div className="lg:w-1/2 w-full lg:pl-10 lg:py-6 mt-6 lg:mt-0">
                            <div className="flex justify-between items-center">
                                <div className="">
                                    {' '}
                                    <h2 className="text-sm title-font text-gray-500  ">{first.country_of_origin}</h2>
                                    <h1 className=" text-foreground text-3xl title-font font-medium mb-1">{first.name}</h1>
                                </div>

                                <span className="inline-flex gap-3">
                                    {/* prefilled value form */}
                                    <HeartIcon className=" text-accent-foreground/60" size={24} strokeWidth={2} />
                                    <PencilLineIcon className=" text-accent-foreground/60" size={24} strokeWidth={2} />
                                    <Share2Icon className=" text-accent-foreground/60" size={24} strokeWidth={2} />
                                </span>
                            </div>
                            <div className="flex mb-4"></div>
                            <p className="leading-relaxed">{first.description}</p>
                        </div>
                    </div>
                </div>
            </section>}
            <Footer /></main>
        </>
    );
};

export default ShastarInfo;
